/*
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _JAVASOFT_BYTEORDER_H_
#define _JAVASOFT_BYTEORDER_H_

#include "byteorder_md.h"

#endif /* !_JAVASOFT_BYTEORDER_H_ */
