Please run this program by double-clicking the 'View.bat' file (in Windows systems). You can also run "Autoplay.bat" or "Autoplay2.bat" file.

If you use Linux or Mac, please get in touch with me to learn how to use it.

Please set your primary monitor's screen resolution to 800 X 600 pixels before running the app to run it in Fullscreen mode. Otherwise, it may display in a small window.
